@extends('layouts.salesApp')
@section('content')
    
@endsection