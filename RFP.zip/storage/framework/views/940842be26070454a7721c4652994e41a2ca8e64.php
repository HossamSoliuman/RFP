
<?php $__env->startSection('content'); ?>
<div class="row justify-content-center">
    <div class="col-md-8">
        <div class="card">
            
            <div class="card-header"><?php echo e(__('Ticket name : ').$ticket_name); ?></div>
                 <div class="card-body">
                    <form method="POST" enctype="multipart/form-data" action="<?php echo e(route('sales.make_request')); ?>">
                       <?php echo csrf_field(); ?>
                       <input type="hidden" name="number_of_questions" value="<?php echo e(count($questions)); ?>">
                       <input type="hidden" name="presales_id" value="<?php echo e($presales_id); ?>">
                       <input type="hidden" name="sales_id" value="<?php echo e($sales_id); ?>">
                       <h3>Customized questions</h3>
                       <?php $__currentLoopData = $questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index=>$question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                       
                     

                       <?php if($question->answer_type=='checkbox'): ?> 
                       <hr>                     
                       <div class="col-xs-4">
                        <label for="vehicle1"> <?php echo e($question->question); ?></label><br>
                        <input type="hidden" name="question[<?php echo e($index); ?>]" value="<?php echo e($question->question); ?>">
                        <?php $__currentLoopData = $question->option; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $x=> $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <input required type="checkbox" id="vehicle1" name="answer[<?php echo e($index); ?>][<?php echo e($x); ?>]" value="<?php echo e($option->name); ?>">
                        <label for="vehicle1"> <?php echo e($option->name); ?></label><br>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                     
                      </div>                    
                       <?php endif; ?>
                       
                     

                       <?php if($question->answer_type=='number'): ?>                      
                       <div class="col-xs-4">
                        <label for="ex3"><?php echo e($question->question); ?></label>
                        <input type="hidden" name="question[<?php echo e($index); ?>]" value="<?php echo e($question->question); ?>">
                        <input required name="answer[<?php echo e($index); ?>]" value=""  class="form-control mb-4" style="height:50px" id="ex3" type="number">
                      </div>                    
                       <?php endif; ?>
                       
                     

                       <?php if($question->answer_type=='text'): ?>                      
                       <div class="col-xs-4">
                        <label for="ex3"><?php echo e($question->question); ?></label>
                        <input type="hidden" name="question[<?php echo e($index); ?>]" value="<?php echo e($question->question); ?>">
                        <input required name="answer[<?php echo e($index); ?>]"   class="form-control mb-4" style="height:50px" id="ex3" type="text">
                      </div>                    
                       <?php endif; ?>
                       

                       <?php if($question->answer_type=='dropdown'): ?>
                     <hr>

                       <label for="ex3"><?php echo e($question->question); ?></label>
                        <input type="hidden" name="question[<?php echo e($index); ?>]" value="<?php echo e($question->question); ?>">
                       <select name="answer[<?php echo e($index); ?>]" class="form-select" aria-label="Default select example">
                        <?php $__currentLoopData = $question->option; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($option->name); ?>"><?php echo e($option->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                      
                      </select>
                       <?php endif; ?>
                       

                       <?php if($question->answer_type=='radio'): ?>
                     <hr>

                       <label for="ex3"><?php echo e($question->question); ?></label><br>
                       <input type="hidden" name="question[<?php echo e($index); ?>]" value="<?php echo e($question->question); ?>">
                       <?php $__currentLoopData = $question->option; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                       <input required type="radio" id="html" name="answer[<?php echo e($index); ?>]" value="<?php echo e($option->name); ?>">
                       <label for="html"><?php echo e($option->name); ?></label><br>
                       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                       <?php endif; ?>
                    
                       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                     
                     <hr>
                     <hr>
                     <h3> Company informations</h3>
                      <div class="col-xs-4 mb-4">
                        <label for="ex3">Company name</label>
                        <input required class="form-control mb-4" type="text" name="cname" >
                      </div>  
                      <div class="col-xs-4 mb-4">
                        <label for="ex3">Company phone</label>
                        <input required class="form-control mb-4" type="text" name="cphone" >
                      </div>  
                      <div class="col-xs-4 mb-4">
                        <label for="ex3">Company offical email address</label>
                        <input required class="form-control mb-4" type="email" name="cemail" >
                      </div>  
                      <div class="col-xs-4 mb-4">
                        <label for="ex3">Company address </label>
                        <input required class="form-control mb-4" type="text" name="caddress" >
                      </div>  
                      
                     <hr>
                     <hr>
                      <h3>Authorized personal information</h3>
                      <div class="col-xs-4 mb-4">
                        <label for="ex3">Person Name</label>
                        <input required class="form-control mb-4" type="text" name="pname" >
                      </div>  
                      <div class="col-xs-4 mb-4">
                        <label for="ex3">Person title</label>
                        <input required class="form-control mb-4" type="text" name="ptitle" >
                      </div>  
                      <div class="col-xs-4 mb-4">
                        <label for="ex3">Person email address</label>
                        <input required class="form-control mb-4" type="email" name="pemail" >
                      </div>  
                      
                     <hr>
                     <hr>
                      <h3>Attached files</h3>
                      <div class="col-xs-4 mb-4">
                        <label for="ex3">CR file</label>
                        <input required class="form-control mb-4" accept=".pdf" type="file" name="cr" >
                      </div>
                      <div class="col-xs-4 mb-4">
                        <label for="ex3">GOSI file</label>
                        <input required class="form-control mb-4" type="file" accept=".pdf" name="gosi" >
                      </div>  
                      <input required type="hidden" name="ticket_name" value="<?php echo e($ticket_name); ?>">
                        <div class="row mb-0">
                            <div class="col-md-6 offset-md-4">
                                <button type="submit" class="btn btn-primary">
                                    <?php echo e(__('Make Request')); ?>

                                </button>
                            </div>
                        </div>
                    </form>                    
                </div>
            </div>
        </div>
    </div>
        
   
   

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.salesApp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\RFP\resources\views/sales/show_questions.blade.php ENDPATH**/ ?>