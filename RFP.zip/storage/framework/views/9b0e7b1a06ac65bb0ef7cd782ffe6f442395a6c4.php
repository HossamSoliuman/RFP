
<?php $__env->startSection('content'); ?>
<div class="container">


<h3 class="text-center">Sales members</h3>
<table class="table table-sm">
    <thead>
      <tr>
        <th scope="col">#</th>
        <th scope="col">Title</th>
        <th scope="col">Email</th>
        <th scope="col">Action</th>
      </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $sales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i=> $sale): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <th scope="row"><?php echo e($i+1); ?> </th>
            <td><?php echo e($sale->name); ?></td>
            <td><?php echo e($sale->email); ?></td>
            <td class="btn-danger btn">  <a  href="<?php echo e(route('admin.delete_user',['id'=>$sale->id])); ?>">Delete</a> </td>
          </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  
    </tbody>
  </table>
  <h3 class="text-center">Presales members</h3>
<table class="table table-sm">
    <thead>
      <tr>
        <th scope="col">#</th>
        <th scope="col">Title</th>
        <th scope="col">Email</th>
        <th scope="col">Solution</th>
        <th scope="col">Action</th>
      </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $presales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i=> $presale): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <th scope="row"><?php echo e($i+1); ?> </th>
            <td><?php echo e($presale->name); ?></td>
            <td><?php echo e($presale->email); ?></td>
            <td><?php echo e($presale->solution->name); ?></td>
            <td class="btn-danger btn ">  <a  href="<?php echo e(route('admin.delete_user',['id'=>$sale->id])); ?>">Delete</a> </td>            
            
          </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  
    </tbody>
  </table>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.adminApp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\RFP\resources\views/admin/show_users.blade.php ENDPATH**/ ?>