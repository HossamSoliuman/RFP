
<?php $__env->startSection('content'); ?>
<table class="table">
    <thead>
      <tr>
        <th scope="col">#</th>
        <th scope="col">Ticket name</th>
        <th scope="col">Status</th>
      </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $tickets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i=> $ticket): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <th scope="row"><?php echo e($i+1); ?></th>
            <td> <a href=" <?php echo e(route('prsales.create_proposal',['ticket_name'=>$ticket->ticket_name])); ?>"><?php echo e($ticket->ticket_name); ?></a> </td>
            <td>
                <?php if($ticket->ticket_status==0): ?>
                <p style="color:brown">Presales didnot review it yet</p>
                <?php endif; ?>
                <?php if($ticket->ticket_status==1): ?>
                <p style="color:rgb(165, 155, 42)">In reviewing</p>
                
                <?php endif; ?>
                <?php if($ticket->ticket_status==2): ?>
                <p style="color:rgb(42, 165, 95)">Approved</p>
                <?php endif; ?>
                <?php if($ticket->ticket_status==-1): ?>
                <p style="color:rgb(193, 46, 14)">Closed</p>
                <?php endif; ?>
                
            </td>
           
          </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
  </table> 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.presalesApp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\RFP\resources\views/presales/follow_ticket.blade.php ENDPATH**/ ?>