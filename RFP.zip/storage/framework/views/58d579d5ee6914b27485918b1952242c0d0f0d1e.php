
<?php $__env->startSection('content'); ?>
<table class="table">
    <thead>
      <tr>
        <th scope="col">#</th>
        <th scope="col">Ticket name</th>
        <th scope="col">Sales team member title</th>
        <th scope="col">Contact</th>
        <th scope="col">Request date</th>
        <th scope="col">Request details</th>
      </tr>
    </thead>
    <tbody>
       
        <?php $__empty_1 = true; $__currentLoopData = $requests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i=> $request): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <tr>
            <th scope="row"><?php echo e($i+1); ?></th>
            <td><?php echo e($request->ticket_name); ?></td>
            <td><?php echo e($request->sales->name); ?></td>
            <td><?php echo e($request->sales->email); ?></td>
            <td><?php echo e($request->request->created_at); ?></td>
            <td> <a href="<?php echo e(route('presales.request_details',['ticket_name'=>$request->ticket_name])); ?>">show details</a></td>
          </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <tr>
            <td colspan="6" class="text-center">You have no requests at this time</td>
           
        </tr>
          <?php endif; ?>
     
      
    </tbody>
  </table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.presalesApp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\RFP\resources\views/presales/requests.blade.php ENDPATH**/ ?>