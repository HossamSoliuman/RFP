
<?php $__env->startSection('content'); ?>
 chat
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.salesApp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\RFP\resources\views/sales/chat.blade.php ENDPATH**/ ?>