
<?php $__env->startSection('content'); ?>
    <div class="container">
        
        <table class="table table-sm">
            <thead>
              <tr>
                <th scope="col">#</th>
                <th scope="col">Ticket name</th>
                <th scope="col">Sales member title</th>
                <th scope="col">Presales title</th>
                <th scope="col">Request info</th>
                <th scope="col">Proposal</th>
                <th scope="col">Status</th>
              </tr>
            </thead>
            <tbody>
                <tr>
                    <td colspan="6"><h3 class="text-center">Waiting</h3></td>
                </tr>
                <?php $__currentLoopData = $waitings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i=> $waiting): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <th scope="row"><?php echo e($i+1); ?></th>
                    <td><?php echo e($waiting->ticket_name); ?></td>
                    <td><?php echo e($waiting->sales->name); ?></td>
                    <td><?php echo e($waiting->presales->name); ?></td>
                    <td> <a href="<?php echo e(route('admin.request_details',['ticket_name'=>$waiting->ticket_name])); ?>">Show request info</a> </td>
                    <td><a href="<?php echo e(route('admin.show_proposal',['ticket_name'=>$waiting->ticket_name])); ?>">Show proposal</a></td>
                    <td>
                        <div class=" alert-warning" role="alert">
                              Waiting
                        </div>  
                    </td>
                  </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <tr>       
                    <td colspan="6"><?php echo $waitings->links(); ?></td>
               </tr>
                <tr>
                    <td colspan="6"><h3 class="text-center">Pending</h3></td>
                </tr>
                <?php $__currentLoopData = $pendings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i=> $pending): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <th scope="row"><?php echo e($i+1); ?></th>
                    <td><?php echo e($pending->ticket_name); ?></td>
                    <td><?php echo e($pending->sales->name); ?></td>
                    <td><?php echo e($pending->presales->name); ?></td>
                    <td> <a href="<?php echo e(route('admin.request_details',['ticket_name'=>$pending->ticket_name])); ?>">Show request info</a> </td>
                    <td><a href="<?php echo e(route('admin.show_proposal',['ticket_name'=>$pending->ticket_name])); ?>">Show proposal</a></td>
                    <td>
                        <div class=" alert-primary" role="alert">
                              Pending
                        </div>  
                    </td>
                  </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                <tr>       
                    <td colspan="6"><?php echo $pendings->links(); ?></td>
               </tr>
                <tr>
                    <td colspan="6"><h3 class="text-center">approved</h3></td>
                </tr> 
                <?php $__currentLoopData = $approveds; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i=> $approved): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <th scope="row"><?php echo e($i+1); ?></th>
                    <td><?php echo e($approved->ticket_name); ?></td>
                    <td><?php echo e($approved->sales->name); ?></td>
                    <td><?php echo e($approved->presales->name); ?></td>
                    <td> <a href="<?php echo e(route('admin.request_details',['ticket_name'=>$approved->ticket_name])); ?>">Show request info</a> </td>
                    <td><a href="<?php echo e(route('admin.show_proposal',['ticket_name'=>$approved->ticket_name])); ?>">Show proposal</a></td>
                    <td>
                        <div class=" alert-success" role="alert">
                              Approved
                        </div>  
                    </td>
                  </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <tr>       
                     <td colspan="6"><?php echo $approveds->links(); ?></td>
                </tr>
                <tr>
                    <td colspan="6"><h3 class="text-center">closed</h3></td>
                </tr>  
                <?php $__currentLoopData = $closeds; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i=> $closed): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <th scope="row"><?php echo e($i+1); ?></th>
                    <td><?php echo e($closed->ticket_name); ?></td>
                    <td><?php echo e($closed->sales->name); ?></td>
                    <td><?php echo e($closed->presales->name); ?></td>
                    <td> <a href="<?php echo e(route('admin.request_details',['ticket_name'=>$closed->ticket_name])); ?>">Show request info</a> </td>
                    <td><a href="<?php echo e(route('admin.show_proposal',['ticket_name'=>$closed->ticket_name])); ?>">Show proposal</a></td>
                    <td>
                        <div class=" alert-danger" role="alert">
                             closed
                         </div>  
                    </td>
                  </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>   
                <tr>       
                    <td colspan="6"><?php echo $closeds->links(); ?></td>
               </tr>   
            </tbody>
          </table>

        
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.adminApp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\RFP\resources\views/admin/show_tickets.blade.php ENDPATH**/ ?>