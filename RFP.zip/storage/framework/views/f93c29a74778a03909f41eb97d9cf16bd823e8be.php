
<?php $__env->startSection('content'); ?>
<div class="row justify-content-center">
    <div class="col-md-8">
        <div class="card">
            <div class="card-header"><?php echo e(__('Number of questions')); ?></div>

            <div class="card-body">
            <?php if(  !isset($_GET['detected']) ): ?>
            
            <form method="GET"  >
                <?php echo csrf_field(); ?>

                <div class="row mb-3">
                    <label for="name" class="col-md-4 col-form-label text-md-end"><?php echo e(__('Number of questions')); ?></label>

                    <div class="col-md-6">
                        <input id="name" type="number" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="number" value="<?php echo e(old('name')); ?>" required autocomplete="name" autofocus>

                        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>

                <div class="row mb-3">
                    <label for="solution" class="col-md-4 col-form-label text-md-end"><?php echo e(__('Select solution')); ?></label>

                    <div class="col-md-6">
                        <select name="solution" class="form-control">
                            <?php $__currentLoopData = $sols; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sol): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($sol->id); ?>"><?php echo e($sol->name); ?></option>                                  
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </select>
                        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>

                <div class="row mb-0">
                    <div class="col-md-6 offset-md-4">
                        <button name="detected" value="1" type="submit" class="btn btn-primary">
                            <?php echo e(__('Done')); ?>

                        </button>
                    </div>
                </div>
            </form> 

                <?php else: ?>
                <form method="POST" action="<?php echo e(route('admin.store_questionnaire')); ?>" >

                    <?php echo csrf_field(); ?>
                    <?php for($i = 0; $i < $_GET['number']; $i++): ?>
                    
                        <div class="row mb-4" >
                          <div class="col">
                            <input name="question[<?php echo e($i); ?>]" type="text" class="form-control" placeholder="Question <?php echo e($i+1); ?>">
                          </div>
                          <div class="col">
                            <select class="form-control" name="type[<?php echo e($i); ?>]" id="">
                                <option value="text">text</option>
                                <option value="number">number</option>
                                <option value="dropdown">dropdown</option>
                                <option value="checkbox">checkbox</option>
                                <option value="radio">radio</option>
                                
                            </select>
                          </div>
                          <div class="col">
                            <input name="option[<?php echo e($i); ?>]" type="text" class="form-control" placeholder="options with '-' seperator">
                          </div>
                        </div>
                      <?php endfor; ?>
                      <input type="hidden" name="sol_id" value="<?php echo e($_GET['solution']); ?>">
                      <input type="hidden" name="all_number" value="<?php echo e($_GET['number']); ?>">
                   <button type="submit">Done</button>
                </form>
                
            <?php endif; ?>
        
               
               
              
            </div>
        </div>
    </div>
</div>
   
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.adminApp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\RFP\resources\views/admin/create_questionnaire.blade.php ENDPATH**/ ?>