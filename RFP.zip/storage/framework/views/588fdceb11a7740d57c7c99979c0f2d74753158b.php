
<?php $__env->startSection('content'); ?>
<div class="row justify-content-center">
    <div class="col-md-8">
        <div class="card">
            
            <div class="card-header"><?php echo e(__('Create Proposal')); ?></div>
                 <div class="card-body">
                    <?php $__empty_1 = true; $__currentLoopData = $previous_modfs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $previous_modf): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <?php if($previous_modf->type=='proposal'): ?>
                        <div class="row">
                          <div class="col-sm-6 ">
                            <div class="card">
                              <div class="card-body">                              
                                <div class="m-4">
                                  <p> GOSI file </p> 
                                  <embed src="<?php echo e(asset('proposals')); ?>/<?php echo e($previous_modf->proposal); ?>"  width="400" height="400">
                                  <p><?php echo e($previous_modf->comment); ?> </p> 
                                  <p><?php echo e($previous_modf->created_at); ?> </p> 
                              </div>
                              </div>
                            </div>
                          </div>                       
                     </div>
                        <?php else: ?>
                        <div class="row d-flex justify-content-end">
                          <div class="col-sm-6 ">
                            <div class="card">
                              <div class="card-body">                              
                                <div class="m-4">                                  
                                  <h6><?php echo e($previous_modf->request_review); ?> </h6> 
                                  <p><?php echo e($previous_modf->created_at); ?> </p> 
                              </div>
                              </div>
                            </div>
                          </div>                       
                     </div> 
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        
                    <?php endif; ?>
                    <div class="row">
                      <div class="col-sm-6 ">
                        <div class="card">
                          <div class="card-body">
                            <?php if($is_closed): ?>
                            <div class="alert alert-danger" role="alert">
                              Closed
                            </div> 
                         
                            <?php elseif($is_approved): ?>
                            <div class="alert alert-success" role="alert">
                              Approved
                            </div>  
                            <?php else: ?>
                            <form method="POST" enctype="multipart/form-data" action="<?php echo e(route('presales.store_proposal')); ?>">
                              <?php echo csrf_field(); ?>   
                              <input type="hidden" name="ticket_name" value="<?php echo e($ticket_name); ?>">                       
                                <div class="form-group">
                                  <label for="exampleInputEmail1">Upload proposal (must be .pdf )</label>
                                  <input type="file" name="proposal" class="form-control" accept=".pdf">
                                </div>
                                <div class="form-group">
                                  <label for="exampleInputPassword1">Comment</label>
                                  <input name="comment" type="text" class="form-control" >
                                </div>                               
                                <button type="submit" class="btn btn-primary">Send</button>                            
                            </form> 
                            <?php endif; ?>
                           
                          </div>
                        </div>
                      </div>
                     
                    
                 </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.presalesApp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\RFP\resources\views/presales/create_proposal.blade.php ENDPATH**/ ?>