
<?php $__env->startSection('content'); ?>
<div class="container">

her
<table class="table">
    <thead>
      <tr>
        
        <th scope="col">Question</th>
        <th scope="col">======></th>
        <th scope="col">Answer</th>
        
      </tr>
    </thead>
    <tbody>
      
        <?php $__empty_1 = true; $__currentLoopData = $request_answers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i=> $request_answer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>            
                <td><?php echo e($request_answer->question); ?></td>
                <td>======></td>
                <td><?php echo e($request_answer->answer); ?></td>            
             </tr>
         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>         
         <?php endif; ?>    
         <tr>
            <td>Company name</td>
            <td>======></td>
            <td> <?php echo e($request->cname); ?> </td>
        </tr> 
        <tr>
            <td>Company phone</td>
            <td>======></td>
            <td> <?php echo e($request->cphone); ?>  </td>
        </tr> 
        <tr>
            <td>Company email</td>
            <td>======></td>
            <td> <?php echo e($request->cemail); ?>  </td>
        </tr> 
        <tr>
            <td>Company address</td>
            <td>======></td>
            <td> <?php echo e($request->caddress); ?>  </td>
        </tr> 
        <tr>
            <td>Person name </td>
            <td>======></td>
            <td> <?php echo e($request->pname); ?>  </td>
        </tr> 
        <tr>
            <td>Person title</td>
            <td>======></td>
            <td> <?php echo e($request->ptitle); ?>  </td>
        </tr> 
        <tr>
            <td>Person email</td>
            <td>======></td>
            <td> <?php echo e($request->pemail); ?>  </td>
        </tr> 
        <tr>
    
            <td>Created at</td>
            <td>======></td>
            <td> <?php echo e($request->created_at); ?> </td>
        </tr> 
        <tr>
            <td></td>
            <td>======></td>
            <td></td>
        </tr> 
        
    </tbody>
  </table>
  <div class="d-flex">
    <div class="m-4">
        <p>CR file</p>
        <embed src="<?php echo e(asset('sales/cr')); ?>/<?php echo e($request->cr); ?>"  width="400" height="400">
    </div>
    <div class="m-4">
        <p> GOSI file </p> 
        <embed src="<?php echo e(asset('sales/gosi')); ?>/<?php echo e($request->gosi); ?>"  width="400" height="400">
    </div>
  </div>
  
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.adminApp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\RFP\resources\views/admin/request_details.blade.php ENDPATH**/ ?>