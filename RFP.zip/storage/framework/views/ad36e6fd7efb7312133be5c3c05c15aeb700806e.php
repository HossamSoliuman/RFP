
<?php $__env->startSection('content'); ?>
<div class="row justify-content-center">
    <div class="col-md-8">
        <div class="card">
            
            <div class="card-header"><?php echo e(__(' Proposal history')); ?></div>
                 <div class="card-body">
                    <?php $__empty_1 = true; $__currentLoopData = $previous_modfs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $previous_modf): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <?php if($previous_modf->type=='proposal'): ?>
                        <div class="row">
                          <div class="col-sm-6 ">
                            <div class="card">
                              <div class="card-body">                              
                                <div class="m-4">
                                  <p> GOSI file </p> 
                                  <embed src="<?php echo e(asset('proposals')); ?>/<?php echo e($previous_modf->proposal); ?>"  width="400" height="400">
                                  <p><?php echo e($previous_modf->comment); ?> </p> 
                                  <p><?php echo e($previous_modf->created_at); ?> </p> 
                              </div>
                              </div>
                            </div>
                          </div>                       
                     </div>
                        <?php else: ?>
                        <div class="row d-flex justify-content-end">
                          <div class="col-sm-6 ">
                            <div class="card">
                              <div class="card-body">                              
                                <div class="m-4">                                  
                                  <h6><?php echo e($previous_modf->request_review); ?> </h6> 
                                  <p><?php echo e($previous_modf->created_at); ?> </p> 
                              </div>
                              </div>
                            </div>
                          </div>                       
                     </div> 
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        
                    <?php endif; ?>
                    <div class="row">
                      <div class="col-sm-6 ">
                        <div class="card">
                          <div class="card-body">
                            <?php if($is_closed): ?>
                            <div class="alert alert-danger" role="alert">
                              Closed
                            </div> 
                         
                            <?php elseif($is_approved): ?>
                            <div class="alert alert-success" role="alert">
                              Approved
                            </div>  
                            <?php else: ?>
                            <?php endif; ?>
                                                   
                         </div>
                        </div>
                      </div>
                     
                    
                 </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.adminApp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\RFP\resources\views/admin/show_proposal.blade.php ENDPATH**/ ?>