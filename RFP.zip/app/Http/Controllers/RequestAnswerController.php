<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class RequestAnswerController extends Controller
{
    //
}
